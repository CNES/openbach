NAME='logpipe'

CFLAGS = []
LDFLAGS = []
LIBS = []
GCC_LIST = ['logpipe']
