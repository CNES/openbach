
NAME='sqlite3'
CFLAGS = []
LDFLAGS = []
LIBS = ['-lsqlite3']

GCC_LIST = ['plugin']
