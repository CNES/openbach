NAME='matheval'

CFLAGS = []
LDFLAGS = []
LIBS = ['-lmatheval']
GCC_LIST = ['math']
